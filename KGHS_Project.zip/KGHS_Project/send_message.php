<?php
session_start();
include 'includes/db.php'; // Include your database connection file
include 'includes/functions.php';

// Validate POST data
if (
    !isset($_SESSION['user_id']) ||
    !isset($_POST['recipient_id']) ||
    !isset($_POST['message_text'])
) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Invalid data']);
    exit;
}

$senderId = $_SESSION['user_id'];
$recipientId = $_POST['recipient_id'];
$messageText = $_POST['message_text'];

// Validate recipient ID (you may need to customize this validation based on your application requirements)
if (!is_numeric($recipientId)) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Invalid recipient ID']);
    exit;
}

// Use prepared statements to prevent SQL injection
$query = "INSERT INTO messages (sender_id, receiver_id, message) VALUES (?, ?, ?)";
$stmt = $conn->prepare($query);

if (!$stmt) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Error preparing statement']);
    exit;
}

$stmt->bind_param('iis', $senderId, $recipientId, $messageText);
$result = $stmt->execute();
$stmt->close();

if ($result) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Error sending message']);
}

exit;
?>
