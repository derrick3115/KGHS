const recipientList = document.getElementById('recipient-list');
const chatMessages = document.getElementById('chat-messages');
const messageForm = document.getElementById('message-form');
const messageInput = document.getElementById('message-input');
const chatTitle = document.getElementById('chat-title');
const closeButton = document.getElementById('close-button');

// (Optional) Add your implementation for fetching available recipients and updating the chat list

closeButton.addEventListener('click', () => {
  // Empty chat window and clear chat title
  chatMessages.innerHTML = '';
  chatTitle.textContent = '-';
});

messageForm.addEventListener('submit', (event) => {
  event.preventDefault();

  const messageText = messageInput.value;
  messageInput.value = '';

  // (Optional) Implement your logic for sending messages to the selected recipient and updating the chat window
});
