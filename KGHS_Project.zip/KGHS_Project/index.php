<?php
// Start or resume a session
session_start();

// Check if the user is already logged in
if (isset($_SESSION['user_id'])) {
    // User is logged in, redirect to the dashboard
    header("Location: dashboard.php");
    exit();
}

// Redirect to the login page
header("Location: login.php");
exit();
?>
