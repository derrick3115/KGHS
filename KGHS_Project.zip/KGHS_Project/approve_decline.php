<?php
session_start();
include 'includes/db.php';
include 'includes/functions.php';

// Check if the user is logged in and is not a parent
if (!isset($_SESSION['user_id']) || get_role_name($_SESSION['role']) == 'parent') {
    header("Location: login.php");
    exit();
}

// Check if the appointment_id and action parameters are set
if (isset($_GET['appointment_id'], $_GET['action'])) {
    $appointmentId = $_GET['appointment_id'];
    $action = $_GET['action'];

    // Update appointment status based on the action (approve/decline)
    if ($action == 'approve') {
        $status = 'approved';
    } elseif ($action == 'decline') {
        $status = 'declined';
    }

    // Update the appointment status in the database
    $success = update_appointment_status($appointmentId, $status);

    if ($success) {
        echo "Appointment {$action}d successfully!";
    } else {
        echo "Failed to {$action} appointment.";
    }
} else {
    echo "Invalid request.";
}
?>
