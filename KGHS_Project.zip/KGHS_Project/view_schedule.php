<?php
session_start();
include 'includes/db.php';
include 'includes/functions.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Retrieve user details
$user = get_user_by_idd($_SESSION['user_id']);
$roleName = get_role_name($user['role']);

// Fetch appointment requests for the logged-in user
$appointmentRequests = get_appointment_requests($user['id']);

// Function to get user details by ID
function get_user_by_idd($userId) {
    global $conn;
    $query = "SELECT * FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo ucfirst($roleName); ?> Schedule - KGHS</title>
    <link rel="stylesheet" href="css/styles.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <style>
        .appointment-list {
            list-style: none;
            padding: 0;
        }

        .appointment-list li {
            margin-bottom: 20px;
            border: 1px solid #ddd;
            padding: 10px;
            border-radius: 8px;
        }

        .approve-btn,
        .decline-btn {
            padding: 5px 10px;
            margin-right: 10px;
            cursor: pointer;
        }

        .approve-btn:hover,
        .decline-btn:hover {
            background-color: #007bff;
            color: #fff;
        }
    </style>
</head>

<body>
    <div class="dashboard-container">
        <div class="header">
            <h2><?php echo ucfirst($roleName); ?> Schedule</h2>
        </div>

        <div class="content">
            <p>Welcome, <?php echo $user['username']; ?>!</p>
            
            <!-- Display appointment requests -->
            <h3>Appointment Requests</h3>
            <ul class="appointment-list">
                <?php foreach ($appointmentRequests as $request): ?>
                    <?php if ($request['status'] === 'pending'): ?>
                        <li>
                            <?php
                            // Get details of the parent making the request
                            $parentDetails = get_user_by_idd($request['parent_id']);
                            $parentName = $parentDetails['username'];
                            $parentRole = get_role_name($parentDetails['role']);
                            ?>

                            <strong>Parent:</strong> <?php echo $parentName; ?> (<?php echo ucfirst($parentRole); ?>)<br>
                            <strong>Date:</strong> <?php echo $request['scheduled_date']; ?><br>
                            <strong>Time:</strong> <?php echo $request['scheduled_time']; ?><br>
                            
                            <!-- Approve and Decline buttons -->
                            <button class="approve-btn" onclick="handleApproval(<?php echo $request['id']; ?>, 'approved')">Approve</button>
                            <button class="decline-btn" onclick="handleApproval(<?php echo $request['id']; ?>, 'declined')">Decline</button>
                        </li>
                    <?php endif; ?>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>

    <script>
        function handleApproval(requestId, status) {
            // Send AJAX request to update the status
            $.ajax({
                type: 'POST',
                url: 'update_appointment_status.php',
                data: {
                    requestId: requestId,
                    status: status
                },
                success: function (response) {
                    alert(response);
                    // Reload the page to reflect changes
                    location.reload();
                },
                error: function (error) {
                    console.error(error);
                    alert('Failed to update appointment status. Please try again.');
                }
            });
        }
    </script>
</body>

</html>
