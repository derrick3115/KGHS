<?php
session_start();
include 'includes/db.php';
include 'includes/functions.php';

// Check if request method is POST and required parameters are set
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['slotId'], $_POST['parentName'], $_POST['parentRole'], $_POST['scheduledDate'], $_POST['scheduledTime'], $_POST['slot'])) {
    $slotId = $_POST['slotId'];
    $parentName = $_POST['parentName'];
    $parentRole = $_POST['parentRole'];
    $scheduledDate = $_POST['scheduledDate'];
    $scheduledTime = $_POST['scheduledTime'];

    // Access slot information from $_POST['slot']
    $slot = $_POST['slot'];

    // Check if user session is valid and get user data
    if (isset($_SESSION['user_id']) && ($user = get_user_by_id($_SESSION['user_id']))) {
        $parentRole = $user['role'];

        // Get recipient data
        $recipient = get_user_by_username($slot['username']);

        // Validate user and slot owner roles and ID existence
        if (($parentRole === 'parent' && $recipient && $recipient['id']) || ($parentRole !== 'parent' && $user['id'])) {
            $parentId = $parentRole === 'parent' ? $user['id'] : $recipient['id'];
            $recipientId = $parentRole === 'parent' ? $recipient['id'] : $user['id'];

            // Prepare and execute query with correct IDs
            $query = "INSERT INTO appointment_requests (parent_id, recipient_id, scheduled_date, scheduled_time, status) VALUES (?, ?, ?, ?, 'pending')";
            $stmt = $conn->prepare($query);
            $stmt->bind_param('iiss', $parentId, $recipientId, $scheduledDate, $scheduledTime);

            if ($stmt->execute()) {
                echo "Appointment request saved successfully!";
            } else {
                echo "Failed to save appointment request. Please try again.";
            }
        } else {
            echo "Invalid recipient information. Please try again.";
        }
    } else {
        echo "Invalid user session. Please log in again.";
    }
} else {
    echo "Invalid request: Some parameters are missing.";
}

?>
