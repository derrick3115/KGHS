<?php
session_start();
include 'includes/db.php';
include 'includes/functions.php';
include 'partials/header.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Check if the logged-in user has the role of school director
if ($_SESSION['role'] !== 'school_director') {
    header("Location: login.php");
    exit();
}

// Process form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_user'])) {
        // Add a new user
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $role = $_POST['role'];
        $child_names = ($role === 'parent') ? $_POST['child_names'] : null;

        add_user($username, $email, $password, $role, $child_names);
    } elseif (isset($_POST['update_user'])) {
        // Update a user's information
        $id = $_POST['user_id'];
        $username = $_POST['username'];
        $email = $_POST['email'];
        $role = $_POST['role'];
        $child_names = ($role === 'parent') ? $_POST['child_names'] : null;

        update_user($id, $username, $email, $role, $child_names);
    } elseif (isset($_POST['delete_user'])) {
        // Delete a user
        $id = $_POST['user_id'];

        delete_user($id);
    } elseif (isset($_POST['edit_user'])) {
        // Edit user - Redirect to an edit page or display a modal
        $user_id = $_POST['user_id'];
        // Example: Redirect to edit page with user_id as a query parameter
        header("Location: edit_user.php?user_id=$user_id");
        exit();
    }
}

// Get the list of all users
$users = get_all_users();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - KGHS</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #34495e;
            margin: 0;
            padding: 0;
            color: #333;
        }

        .dashboard-container {
            max-width: 800px;
            margin: auto;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-top: 20px;
            border-radius: 8px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        form {
            margin-bottom: 10px;
        }

        h2, h3 {
            color: #333;
        }

        hr {
            border: 0;
            height: 1px;
            background: #ddd;
            margin-top: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
            color: #555;
        }

        button {
            background-color: #28a745;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #218838;
        }

        .actions {
            display: flex;
        }

        .actions form {
            margin-right: 10px;
        }

        .actions button {
            background-color: #dc3545;
        }

        .actions button:hover {
            background-color: #c82333;
        }
    </style>
    <script>
        function confirmDelete() {
            return confirm("Are you sure you want to delete this user?");
        }
    </script>
</head>
<body>
    <div class="dashboard-container">
        <div class="header">
            <h2>Manage Users</h2>
        </div>

        <div class="content">
            <!-- Display users and provide forms for adding, updating, and deleting users -->
            <table>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Child Names (for Parent)</th>
                    <th>Actions</th>
                </tr>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?php echo $user['id']; ?></td>
                        <td><?php echo $user['username']; ?></td>
                        <td><?php echo $user['email']; ?></td>
                        <td><?php echo $user['role']; ?></td>
                        <td><?php echo ($user['role'] === 'parent' && is_serialized($user['child_names'])) ? implode(', ', (array) unserialize($user['child_names'])) : $user['child_names']; ?></td>
                        <td class="actions">
                            <!-- Edit button -->
                            <form method="post" onsubmit="return confirmDelete();">
                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                <button type="submit" name="edit_user">Edit</button>
                            </form>

                            <!-- Other actions (Delete) -->
                            <form method="post" onsubmit="return confirmDelete();">
                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                <button type="submit" name="delete_user">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>

            <hr>

            <!-- Form for adding a new user -->
            <h3>Add New User</h3>
            <form method="post">
                <label for="username">Username:</label>
                <input type="text" name="username" required>
                <br>
                <label for="email">Email:</label>
                <input type="email" name="email" required>
                <br>
                <label for="password">Password:</label>
                <input type="password" name="password" required>
                <br>
                <label for="role">Role:</label>
                <select name="role" required>
                    <option value="teacher">Teacher</option>
                    <option value="head_teacher">Head Teacher</option>
                    <option value="school_director">School Director</option>
                    <option value="parent">Parent</option>
                </select>
                <br>
                <label for="child_names">Child Names (for Parent):</label>
                <input type="text" name="child_names" placeholder="Comma-separated names" <?php echo (isset($_POST['role']) && $_POST['role'] !== 'parent') ? 'disabled' : ''; ?>>
                <br>
                <button type="submit" name="add_user">Add User</button>
            </form>
        </div>
    </div>
</body>
</html>
