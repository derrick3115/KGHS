<?php
session_start();
include 'includes/db.php';
include 'includes/functions.php';
include 'partials/header.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Check if the logged-in user has the role of school director
if ($_SESSION['role'] !== 'school_director') {
    header("Location: login.php");
    exit();
}

// Check if the user_id is provided in the URL
if (!isset($_GET['user_id']) || empty($_GET['user_id'])) {
    // Redirect to a page indicating that user_id is missing
    header("Location: error.php?message=User ID is missing");
    exit();
}

$user_id = $_GET['user_id'];

// Fetch user details by ID
$user = get_user_by_id($user_id);

// Check if the user exists
if (!$user) {
    // Redirect to a page indicating that the user was not found
    header("Location: error.php?message=User not found");
    exit();
}

// Process form submissions
$update_status = null; // Variable to track update status

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_user'])) {
        // Update a user's information
        $username = $_POST['username'];
        $email = $_POST['email'];
        $role = $_POST['role'];
        $child_names = ($role === 'parent' && isset($_POST['child_names'])) ? $_POST['child_names'] : null;

        // Check if child_names is not set, set it to null
        if (!isset($child_names)) {
            $child_names = null;
        }

        // Update the user
        if (update_user($user_id, $username, $email, $role, $child_names)) {
            $update_status = true; // Update successful
            // Fetch user details again after the update
            $user = get_user_by_id($user_id);

            // Redirect to manage_administration.php
            header("Location: manage_administration.php");
            exit();
        } else {
            $update_status = false; // Update failed
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User - KGHS</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        /* Add your custom styles here */
        form {
            max-width: 400px; /* Adjust the max-width as needed */
            margin: auto;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input,
        select {
            width: 100%;
            padding: 8px;
            margin-bottom: 12px;
            box-sizing: border-box;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        .message {
            margin-top: 10px;
            padding: 10px;
            border-radius: 4px;
        }

        .success {
            background-color: #4CAF50;
            color: white;
        }

        .error {
            background-color: #f44336;
            color: white;
        }
    </style>
    <!-- Add any additional styles or scripts here -->
</head>
<body>
    <div class="dashboard-container">
        <div class="header">
            <h2>Edit User</h2>
        </div>

        <div class="content">
            <!-- Display update status message -->
            <?php if ($update_status !== null): ?>
                <div class="message <?php echo ($update_status) ? 'success' : 'error'; ?>">
                    <?php echo ($update_status) ? 'Update successful' : 'Update failed'; ?>
                </div>
            <?php endif; ?>

            <!-- Form for updating user information -->
            <form method="post">
                <label for="username">Username:</label>
                <input type="text" name="username" value="<?php echo $user['username']; ?>" required>
                <label for="email">Email:</label>
                <input type="email" name="email" value="<?php echo $user['email']; ?>" required>
                <label for="role">Role:</label>
                <select name="role" required>
                    <option value="teacher" <?php echo ($user['role'] === 'teacher') ? 'selected' : ''; ?>>Teacher</option>
                    <option value="head_teacher" <?php echo ($user['role'] === 'head_teacher') ? 'selected' : ''; ?>>Head Teacher</option>
                    <option value="school_director" <?php echo ($user['role'] === 'school_director') ? 'selected' : ''; ?>>School Director</option>
                    <option value="parent" <?php echo ($user['role'] === 'parent') ? 'selected' : ''; ?>>Parent</option>
                </select>
                <label for="child_names">Child Names (for Parent):</label>
                <input type="text" name="child_names" value="<?php echo ($user['role'] === 'parent') ? getChildNamesValue($user['child_names']) : ''; ?>" placeholder="Comma-separated names">

                <button type="submit" name="update_user">Update User</button>
            </form>
        </div>
    </div>

    <?php include 'partials/footer.php'; ?>
</body>
</html>
