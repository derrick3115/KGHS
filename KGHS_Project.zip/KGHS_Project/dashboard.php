<?php
// Include necessary files
include 'includes/db.php';
include 'includes/functions.php';
include 'partials/header.php';

// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    // User is not logged in, redirect to the login page
    header("Location: login.php");
    exit();
}
?>

<!-- HTML for the user dashboard -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KGHS Dashboard</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h2>Welcome to KGHS Dashboard</h2>

    <!-- Display user-specific dashboard content here -->

    <?php include 'partials/footer.php'; ?>
</body>
</html>
