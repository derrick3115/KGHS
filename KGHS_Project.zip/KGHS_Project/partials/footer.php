</main>
    <footer>
        <div class="container">
            <p style="color:white;">&copy; <?php echo date('Y'); ?> Kigali Greater Heights School</p>
        </div>
    </footer>
    <!-- Add your scripts and additional closing tags here
