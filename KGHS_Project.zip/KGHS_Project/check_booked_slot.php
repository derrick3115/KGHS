<?php
session_start();
include 'includes/db.php';

// Check if required parameters are set
if (!isset($_POST['slotId'])) {
  exit('Invalid request.');
}

$slotId = (int) $_POST['slotId'];

// Query to check if the slot is booked
$query = "SELECT COUNT(*) FROM appointment_requests WHERE slot_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('i', $slotId);
$stmt->execute();
$result = $stmt->get_result();

$isBooked = (int) $result->fetch_assoc()['COUNT(*)'] > 0;

// Send response indicating if the slot is booked
echo json_encode($isBooked);
?>