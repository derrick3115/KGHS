<?php
session_start();
include 'includes/db.php';
include 'includes/functions.php';
include 'partials/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Appointments - KGHS</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        /* Add your styles for the view appointments page here */
    </style>
</head>
<body>
    <div class="dashboard-container">
        <h2>View Your Appointments</h2>

        <?php
        // Retrieve appointments for the current parent
        $parentAppointments = get_parent_appointments($_SESSION['user_id']);

        if (!empty($parentAppointments)) {
            // Display the list of appointments
            echo '<ul>';
            foreach ($parentAppointments as $appointment) {
                echo '<li>';
                echo 'Appointment ID: ' . $appointment['id'] . '<br>';
                echo 'Teacher ID: ' . $appointment['teacher_id'] . '<br>';
                echo 'Status: ' . $appointment['status'] . '<br>';
                echo 'Appointment Time: ' . $appointment['appointment_time'] . '<br>';
                echo 'Created At: ' . $appointment['created_at'] . '<br>';
                echo '<a href="select_appointment.php?id=' . $appointment['id'] . '">Select Appointment</a>';
                echo '</li>';
            }
            echo '</ul>';
        } else {
            echo '<p>No appointments found.</p>';
        }
        ?>

        <div class="actions">
            <a href="parent_dashboard.php">Back to Dashboard</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>

    <?php include 'partials/footer.php'; ?>
</body>
</html>
