<?php
session_start();
include 'includes/db.php';
include 'includes/functions.php';
include 'partials/header.php';

// Check if the user is logged in and is a head teacher
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'head_teacher') {
    header("Location: login.php");
    exit();
}

// Retrieve head teacher details
$headTeacher = get_user_by_id($_SESSION['user_id']);

// Get a list of classes for the head teacher
$classes = get_classes_for_head_teacher($headTeacher['id']);

// Handle announcement form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['announcement_text'])) {
    $announcementText = $_POST['announcement_text'];

    // Add your logic to store the announcement in the database or perform other actions
    // For example, you can create a function like add_announcement($text) in includes/functions.php
    $success = add_announcement($headTeacher['id'], $announcementText);

    if ($success) {
        echo "Announcement saved successfully!";
    } else {
        echo "Failed to save announcement.";
    }
}

// Handle schedule form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['schedule_teacher_id'], $_POST['schedule_date'], $_POST['schedule_time'])) {
    $teacherId = $_POST['schedule_teacher_id'];
    $scheduleDate = $_POST['schedule_date'];
    $scheduleTime = $_POST['schedule_time'];

    // Replace with your actual function name (e.g., schedule_appointment)
    $success = schedule_appointment($headTeacher['id'], $teacherId, $scheduleDate . ' ' . $scheduleTime);

    if ($success) {
        echo "Schedule set successfully!";
    } else {
        echo "Failed to set schedule.";
    }
}
// Fetch notifications for the head teacher
$notifications = get_user_notifications($_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Head Teacher Dashboard - KGHS</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        /* Additional styles for improved design */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #34495e;
            margin: 0;
            padding: 0;
        }

        .dashboard-container {
            max-width: 800px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
        }

        .content {
            margin-top: 20px;
            color: black;
        }

        .class-list {
            list-style: none;
            padding: 0;
        }

        .class-list li {
            margin-bottom: 10px;
            background-color: #f0f0f0;
            padding: 10px;
            border-radius: 5px;
        }

        .button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            margin-right: 10px;
            cursor: pointer;
        }

        .button:hover {
            background-color: #0056b3;
        }

        .notification-bar {
            background-color: #4caf50;
            color: #fff;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            position: relative;
            display: inline-block;
        }

        .badge {
            background-color: #ff5252;
            color: #fff;
            padding: 4px 8px;
            border-radius: 50%;
            position: absolute;
            top: 0;
            right: 0;
        }

        .notification-list {
            display: none;
            list-style: none;
            padding: 0;
            margin-top: 10px;
        }

        .notification-list li {
            margin-bottom: 5px;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
            padding-top: 60px;
        }

        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            border-radius: 5px;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
        }

        textarea {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            margin-bottom: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
            resize: vertical;
        }

        .submit-btn {
            background-color: #4caf50;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        .submit-btn:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>
    <div class="dashboard-container">
        <div class="header">
            <h2>Welcome, <?php echo $headTeacher['username']; ?>!</h2>
        </div>

        <div class="content">
            <h3>Actions</h3>
            <a href="send_query.php?role=head_teacher" class="button">Messages Queries</a>
            <a href="#" class="button" id="makeAnnouncementBtn">Make Announcement</a>
            <a href="scheduler.php" class="button" id="setScheduleBtn">Set Schedule</a>
            <a onclick="viewAnnouncements()" class="button">view Announcements</a>

            <!-- Notification bar -->
            <div class="notification-bar" onclick="toggleNotifications()">
                Notifications
                <span class="badge" id="notificationBadge"><?php echo count($notifications); ?></span>
            </div>

            <!-- Notification list -->
            <ul class="notification-list" id="notificationList">
                <?php foreach ($notifications as $notification): ?>
                    <li><?php echo $notification['message']; ?></li>
                <?php endforeach; ?>
            </ul>

            <p><a href="logout.php">Logout</a></p>
        </div>
    </div>

    <!-- Modal for making announcements -->
    <div id="announcementModal" class="modal">
        <div class="modal-content">
            <span class="close" id="closeAnnouncementModal">&times;</span>
            <h2>Make Announcement</h2>
            <form method="post" action="">
                <label for="announcement_text">Announcement Text:</label>
                <textarea id="announcement_text" name="announcement_text" rows="4" required></textarea>
                <br>
                <input type="submit" class="submit-btn" value="Submit">
            </form>
        </div>
    </div>

    <script>
        // Function to view announcements
        function viewAnnouncements() {
            // Redirect to the page where teacher can view announcements
            window.location.href = 'view_announcements.php';
        }

        // Toggle notification list visibility
        function toggleNotifications() {
            const notificationList = document.getElementById('notificationList');
            notificationList.style.display = notificationList.style.display === 'block' ? 'none' : 'block';

            // Reset badge count
            document.getElementById('notificationBadge').textContent = '0';
        }

        // Modal functionality
        function openModal(modalId) {
            const modal = document.getElementById(modalId);
            modal.style.display = 'block';
        }

        function closeModal(modalId) {
            const modal = document.getElementById(modalId);
            modal.style.display = 'none';
        }

        document.getElementById('makeAnnouncementBtn').addEventListener('click', () => {
            openModal('announcementModal');
        });

        document.getElementById('setScheduleBtn').addEventListener('click', () => {
            openModal('scheduleModal');
        });

        document.getElementById('closeAnnouncementModal').addEventListener('click', () => {
            closeModal('announcementModal');
        });

        document.getElementById('closeScheduleModal').addEventListener('click', () => {
            closeModal('scheduleModal');
        });

        // Display notifications
        function displayNotifications() {
            const notifications = <?php echo json_encode($notifications); ?>;
            const notificationList = document.querySelector('.notification-list');

            notifications.forEach(notification => {
                const listItem = document.createElement('li');
                listItem.textContent = notification.message;
                notificationList.appendChild(listItem);
            });
        }

        // Call the function to display notifications
        displayNotifications();
    </script>
</body>

</html>
