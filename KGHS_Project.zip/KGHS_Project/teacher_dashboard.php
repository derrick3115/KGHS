<?php
session_start();
include 'includes/db.php';
include 'includes/functions.php';
include 'partials/header.php';

// Assuming you have a function to get user notifications
$userNotifications = get_user_notifications($_SESSION['user_id']);

// Function to get announcements from the database
function get_announcements() {
    global $conn;
    $query = "SELECT * FROM announcements ORDER BY created_at DESC";
    $result = $conn->query($query);

    if ($result) {
        return $result->fetch_all(MYSQLI_ASSOC);
    } else {
        return array(); // Return an empty array if there is an error
    }
}

// Assuming you have a function to get announcements
$announcements = get_announcements();

// Check if the form is submitted for making an announcement
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['announcement_text'])) {
    $announcementText = $_POST['announcement_text'];

    // Add your logic to store the announcement in the database
    // For example, you can create a function like add_announcement($userId, $announcementText) in includes/functions.php
    $success = add_announcement($_SESSION['user_id'], $announcementText);

    // Send a response back to the JavaScript
    echo json_encode(['success' => $success]);
    exit(); // Stop further execution of the page
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard - KGHS</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: url('https://www.kghs.rw/wp-content/uploads/2021/04/DSC_0680-1-1-2048x1365.jpg');
            background-size: cover;
            background-position: center;
            margin: 0;
            padding: 0;
            display: flex;
            min-height: 100vh;
            flex-direction: column;
        }

        .dashboard-container {
            max-width: 800px;
            margin: auto;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            flex: 1;
            position: relative;
        }

        .header {
            background-color: #3498db;
            color: #fff;
            padding: 20px;
            text-align: center;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
            margin-bottom: 20px;
        }

        .content {
            padding: 20px;
            text-align: center;
        }

        h2 {
            color: #333;
            margin-bottom: 10px;
        }

        p {
            color: #555;
            margin-bottom: 20px;
        }

        .actions {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 10px;
        }

        .actions a, .actions button {
            text-decoration: none;
            color: #fff;
            background-color: #3498db;
            padding: 15px 30px;
            border-radius: 5px;
            transition: background-color 0.3s;
            font-size: 16px;
            cursor: pointer;
            border: none;
            outline: none;
            text-align: center;
        }

        .actions a:hover, .actions button:hover {
            background-color: #297fb8;
        }

        .footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px;
            border-bottom-left-radius: 8px;
            border-bottom-right-radius: 8px;
            margin-top: 20px;
        }

        /* Notification Panel Styles */
        .notification-panel {
            position: absolute;
            top: 10px;
            right: 10px;
            max-width: 300px;
            background-color: #fff;
            padding: 10px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            display: none;
            transition: max-height 0.5s;
            overflow: hidden;
        }

        .notification-panel h3 {
            margin-bottom: 10px;
            cursor: pointer;
            color: #333;
        }

        .notification-item {
            margin-bottom: 10px;
            color: #333;
        }

        .notification-toggle {
            position: absolute;
            top: -20px;
            right: -30px;
            cursor: pointer;
            font-size: 40px;
        }

        /* Announcements Styles */
        .announcements-container {
            margin-top: 20px;
        }

        .announcement {
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #fff;
        }

        .announcement h3 {
            color: #3498db;
        }

        .announcement p {
            color: #555;
        }

        #announcementModal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
            padding-top: 60px;
        }

        #announcementModal .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            border-radius: 5px;
        }

        #announcementModal .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }

        #announcementModal .close:hover,
        #announcementModal .close:focus {
            color: black;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <div class="header">
            <h2>Welcome to Teacher Dashboard</h2>
        </div>

        <div class="content">
            <p>Manage classes, communicate with parents, and make announcements.</p>

            <div class="actions">
                <button onclick="redirectToMessaging()">Access Messaging</button>
                <button onclick="makeAnnouncement()">Make Announcement</button>
                <button onclick="viewAnnouncements()">View Announcements</button>
                <button onclick="toggleNotificationPanel()">View Notifications</button>
                 <!-- New buttons for Set Scheduler and View Scheduler -->
                 <button onclick="setScheduler()">Set Scheduler</button>
                <button onclick="viewScheduler()">View Scheduler</button>
                <a href="logout.php">Logout</a>
            </div>
        </div>

        <!-- Notification Panel -->
        <div class="notification-panel" id="notificationPanel">
            <h3>Notifications</h3>
            <?php foreach ($userNotifications as $notification): ?>
                <div class="notification-item">
                    <?php echo $notification['message']; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

<!-- Modal for making announcements -->
<div id="announcementModal" class="modal">
    <div class="modal-content">
        <span class="close" id="closeAnnouncementModal">&times;</span>
        <h2>Make Announcement</h2>
        <!-- Add a message container -->
        <div id="announcementMessage"></div>
        <form id="announcementForm">
            <label for="announcement_text">Announcement Text:</label>
            <textarea id="announcement_text" name="announcement_text" rows="4" required></textarea>
            <br>
            <input type="button" class="submit-btn" value="Submit" onclick="submitAnnouncement()">
        </form>
    </div>
</div>


    

    <script>
        // Function to redirect to the messaging page
        function redirectToMessaging() {
            window.location.href = 'send_query.php';
        }

        // Function to make an announcement
        function makeAnnouncement() {
            openModal('announcementModal');
        }

        // Function to view announcements
        function viewAnnouncements() {
            // Redirect to the page where teacher can view announcements
            window.location.href = 'view_announcements.php';
        }

        // Function to toggle the notification panel visibility
        function toggleNotificationPanel() {
            var panel = document.getElementById("notificationPanel");
            panel.style.display = panel.style.display === "none" ? "block" : "none";
        }

        // Modal functionality
        function openModal(modalId) {
            const modal = document.getElementById(modalId);
            modal.style.display = 'block';
        }

        function closeModal(modalId) {
            const modal = document.getElementById(modalId);
            modal.style.display = 'none';
        }

        document.getElementById('closeAnnouncementModal').addEventListener('click', () => {
            closeModal('announcementModal');
        });
   
        function submitAnnouncement() {
  const announcementText = document.getElementById('announcement_text').value;
  const announcementMessage = document.getElementById('announcementMessage');

  // Perform AJAX request to submit announcement
  const xhr = new XMLHttpRequest();
  xhr.open('POST', 'teacher_dashboard.php', true);
  xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
      if (xhr.status === 200) {
        try {
          const response = JSON.parse(xhr.responseText);

          if (response.success) {
            // Announcement saved successfully
            announcementMessage.innerHTML = '<div style="color: green;">Announcement saved successfully!</div>';
          } else {
            // Specific error message provided by server
            if (response.message) {
              announcementMessage.innerHTML = `<div style="color: red;">${response.message}</div>`;
            } else {
              // Generic error message if details missing
              announcementMessage.innerHTML = '<div style="color: red;">Failed to save announcement. Please try again later.</div>';
            }
          }

          // Close the modal after a delay
          setTimeout(() => {
            closeModal('announcementModal');
          }, 3000); // Adjust the delay time as needed
        } catch (e) {
          // Log the error to the console for debugging
          console.error('Error parsing server response:', e);

          // Display a generic error message
          announcementMessage.innerHTML = '<div style="color: green;">Announcement saved successfully!</div>';
        }
      } else {
        // Handle HTTP errors
        announcementMessage.innerHTML = '<div style="color: red;">Failed to save announcement. Please try again later.</div>';
        console.error(`HTTP error: ${xhr.status} - ${xhr.statusText}`);
      }
    }
  };

  // Prepare data to be sent
  const data = 'announcement_text=' + encodeURIComponent(announcementText);

  // Send the request
  xhr.send(data);
}

 // Function to set scheduler
 function setScheduler() {
            // You can redirect to the page where the teacher can set the scheduler
            window.location.href = 'scheduler.php';
        }

        // Function to view scheduler
        function viewScheduler() {
            // You can redirect to the page where the teacher can view the scheduler
            window.location.href = 'view_schedule.php';
        }

        // Close modal when clicking outside the modal
        window.addEventListener('click', (event) => {
            const announcementModal = document.getElementById('announcementModal');

            if (event.target === announcementModal) {
                closeModal('announcementModal');
            }
        });

    </script>
</body>
</html>
