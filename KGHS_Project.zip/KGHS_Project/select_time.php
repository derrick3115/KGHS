<?php
session_start();
include 'includes/db.php';
include 'includes/functions.php';
include 'partials/header.php';

if (isset($_GET['slot_id'])) {
    $selectedSlotId = $_GET['slot_id'];

    // Get the user ID of the logged-in parent
    $parentId = $_SESSION['user_id'];

    // Process the selected time slot and insert a request
    $success = create_appointment_request($parentId, $selectedSlotId);

    if ($success) {
        echo '<p>Appointment request sent successfully!</p>';
        // You can also notify the parent about the request
    } else {
        echo '<p>Failed to send appointment request.</p>';
    }
}

// Example code (modify based on your actual implementation)
if (isset($_POST['approve_appointment'])) {
    $appointmentId = $_POST['appointment_id'];
    $success = approve_appointment($appointmentId);

    if ($success) {
        echo "Appointment approved successfully!";
    } else {
        echo "Failed to approve appointment.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Time - KGHS</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        /* Add your styles for the select time page here */
    </style>
</head>
<body>
    <div class="dashboard-container">
        <h2>Select Time</h2>

        <!-- Add form or confirmation message for the selected time slot -->
        <!-- Use the $selectedSlotId to update the database and notify the parent -->

        <div class="actions">
            <a href="parent_dashboard.php">Back to Dashboard</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>

    <?php include 'partials/footer.php'; ?>
</body>
</html>
