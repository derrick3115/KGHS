<?php
include 'includes/db.php';
include 'includes/functions.php';
include 'partials/header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the required keys exist in $_POST
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $confirm_password = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';
    $child_names = isset($_POST['child_names']) ? $_POST['child_names'] : [];

    if (empty($username) || empty($email) || empty($password) || empty($confirm_password) || empty($child_names)) {
        echo "All fields are required!";
    } elseif ($password !== $confirm_password) {
        echo "Passwords do not match!";
    } elseif (username_exists($username)) {
        echo "Username already exists!";
    } elseif (email_exists($email)) {
        echo "Email already exists!";
    } else {
        if (register_user($username, $email, $password, $child_names, 'parent')) {
            echo "Registration successful!";
        } else {
            echo "Registration failed!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - KGHS</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="register-container">
        <h2>Register for KGHS</h2>

        <form action="" method="post" class="register-form">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <label for="confirm_password">Confirm Password:</label>
            <input type="password" id="confirm_password" name="confirm_password" required>

            <label for="child_names">Child's Names (comma-separated):</label>
            <input type="text" id="child_names" name="child_names" required>

            <button type="submit">Register</button>
        </form>

        <p>Already have an account? <a href="login.php">Login here</a>.</p>
    </div>

    <?php include 'partials/footer.php'; ?>
</body>
</html>
