<?php
// get_new_messages.php

session_start();

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'User ID not set in the session']);
    exit;
}

$userId = $_SESSION['user_id'];
$recipientId = isset($_GET['recipient_id']) ? $_GET['recipient_id'] : null;

if (!$recipientId) {
    echo json_encode(['success' => false, 'error' => 'Recipient ID not provided']);
    exit;
}

$servername = "localhost";
$username = "root"; // Replace with your actual username
$password = ""; // Replace with your actual password
$dbname = "kghs_database";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Connection failed: ' . $conn->connect_error]);
    exit;
}

$query = "SELECT * FROM messages WHERE (sender_id = '$userId' AND recipient_id = '$recipientId') OR (sender_id = '$recipientId' AND recipient_id = '$userId') ORDER BY timestamp";
$result = $conn->query($query);

if (!$result) {
    echo json_encode(['success' => false, 'error' => 'Error executing query: ' . $conn->error]);
    exit;
}

$messages = [];

while ($row = $result->fetch_assoc()) {
    $messages[] = [
        'sender_id' => $row['sender_id'],
        'message_text' => $row['message_text'],
        'timestamp' => $row['timestamp'],
    ];
}

echo json_encode(['success' => true, 'messages' => $messages]);
exit;
?>