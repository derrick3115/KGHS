<?php
$servername = "localhost";
$username = "root"; // Replace with your actual username
$password = ""; // Replace with your actual password
$dbname = "kghs_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to get user information by ID
function getUserInfo($userId, $conn) {
    $query = "SELECT * FROM users WHERE id = '$userId'";
    $result = $conn->query($query);

    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc();
    } else {
        return false;
    }
}

// Get user ID from the request
if (isset($_GET['user_id'])) {
    $userId = $_GET['user_id'];

    // Get user information
    $userInfo = getUserInfo($userId, $conn);

    if ($userInfo) {
        // Return user information as JSON
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'user_name' => $userInfo['username'],
            'user_role' => $userInfo['role'],
            'user_id' => $userInfo['id']
        ]);
    } else {
        // User not found
        echo json_encode([
            'success' => false,
            'error' => 'User not found.'
        ]);
    }
} else {
    // User ID not provided in the request
    echo json_encode([
        'success' => false,
        'error' => 'User ID not provided in the request.'
    ]);
}

// Close connection
$conn->close();
?>
