<!-- parent_schedule.php -->

<?php
session_start();
include 'includes/db.php';
include 'includes/functions.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Retrieve user details
$user = get_user_by_id($_SESSION['user_id']);
$roleName = get_role_name($user['role']);

// Get available slots from the "available_slots" table
$availableSlots = get_available_slots();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo ucfirst($roleName); ?> Scheduler - KGHS</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Your custom styles -->
    <style>
        body {
            background-color: #f8f9fa;
        }

        .dashboard-container {
            max-width: 800px;
            margin: 0 auto;
        }

        .header {
            background-color: #007bff;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        .content {
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-top: 20px;
        }

        .appointment-list {
            list-style: none;
            padding: 0;
        }

        .appointment-list li {
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    <div class="dashboard-container">
        <div class="header">
            <h2>Welcome, <?php echo $user['username']; ?>! (<?php echo ucfirst($roleName); ?>)</h2>
        </div>

        <div class="content">
            <!-- Display available slots for parents to select -->
            <h3 class="text-center">Available Slots</h3>
            <!-- Display available slots for parents to select -->
            <ul class="list-group">
                <?php foreach ($availableSlots as $slot): ?>
  <li class="list-group-item">
    <?php
      $userDetails = get_user_by_username($slot['username']);
      $isSlotBooked = is_slot_booked($slot['id']);

      echo "Name: {$slot['username']}, Date: {$slot['available_date']}, Time: {$slot['available_time_from']}";

      if (!$isSlotBooked) {
        echo '&nbsp;&nbsp;<button class="btn btn-primary" onclick="selectTimeSlot(' . $slot['id'] . ', \'' . $slot['username'] . '\', \'' . $userDetails['role'] . '\', \'' . $slot['available_date'] . '\', \'' . $slot['available_time_from'] . '\', ' . htmlspecialchars(json_encode($slot), ENT_QUOTES, 'UTF-8') . ')">Select Time Slot</button>';
      } else {
        echo '&nbsp;&nbsp;<button class="btn btn-primary disabled" onclick="alert(\'This slot is already booked.\')">Select Time Slot</button>';
      }
    ?>
  </li>
<?php endforeach; ?>
            </ul>

        </div>
    </div>


    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Your custom scripts or additional calendar scripts -->
    <script>
    function selectTimeSlot(slotId, username, roleName, selectedDate, selectedTime, slot) {
        // Log the data being sent to the console
        console.log({
            slotId: slotId,
            parentName: username,
            parentRole: roleName,
            scheduledDate: selectedDate,
            scheduledTime: selectedTime,
            slot: slot
        });

        // Send an AJAX request to save the selected time slot
        $.ajax({
            type: 'POST',
            url: 'save_appointment_request.php',
            data: {
                slotId: slotId,
                parentName: username,
                parentRole: roleName,
                scheduledDate: selectedDate,
                scheduledTime: selectedTime,
                slot: slot  // Pass the slot information
            },
            success: function (response) {
                alert(response);
            },
            error: function (error) {
                console.error(error);
                alert('Failed to save appointment request. Please try again.');
            }
        });
    }
</script>

</body>

</html>
