<?php
session_start();

if (!isset($_SESSION['role']) || !isset($_SESSION['user_id'])) {
    echo "User role or ID not set in the session. Please log in.";
    exit;
}

$userRole = $_SESSION['role'];
$userId = $_SESSION['user_id'];

$servername = "localhost";
$username = "root"; // Replace with your actual username
$password = ""; // Replace with your actual password
$dbname = "kghs_database";

include 'partials/header.php';

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function sendQuery($query) {
    global $conn;

    $result = $conn->query($query);

    if (!$result) {
        echo "Error executing query: " . $conn->error;
        return false;
    }

    return $result;
}

// Retrieve users based on the user's role
$query = "SELECT * FROM users WHERE role != '$userRole' AND id != '$userId'";
$result = sendQuery($query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat App</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-xxxxxxx" crossorigin="anonymous" />

    <style>
        body {
            margin: 0;
            font-family: 'Arial', sans-serif;
            background-color: #f0f0f0;
            color: #333; /* Adjusted text color */
        }

        .chat-container {
            display: flex;
            width: 100vw;
            height: 100vh;
        }

        .recipient-container {
            flex: 1;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            margin: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .recipient-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .recipient-item {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            cursor: pointer;
        }

        .chat-window {
            flex: 3;
            background-color: #ffffff;
            border-radius: 10px;
            margin: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
        }

        .chat-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            border-bottom: 1px solid #ddd;
            border-radius: 10px 10px 0 0;
            background-color: #007bff;
            color: #ffffff;
        }

        .chat-title {
            font-size: 18px;
        }

        #close-button {
            cursor: pointer;
        }

        .chat-messages {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
        }

        .message {
            display: flex;
            flex-direction: column;
            margin-bottom: 20px;
        }

        .message-content {
            padding: 15px;
            border-radius: 10px;
            margin: 0 10px;
            max-width: 70%;
        }

        .sender-message-content {
            background-color: gray;
            align-self: flex-end;
        }

        .received-message-content {
            background-color: #e0f2f1;
            align-self: flex-start;
        }

        .timestamp {
            font-size: 12px;
            color: #999;
            margin-top: 5px;
        }

        .message-form {
            padding: 20px;
            border-top: 1px solid #ddd;
            border-radius: 0 0 10px 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        #message-input {
            flex: 1;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
            box-sizing: border-box;
        }

        #send-button {
            margin-left: 10px;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #007bff;
            color: #ffffff;
            cursor: pointer;
            max-width: 100px;
            border: 1px solid #000;
        }
        .popup {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        justify-content: center;
        align-items: center;
    }

    /* Popup content */
    .popup-content {
        background: #fff;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        max-width: 400px;
        width: 100%;
    }

    /* Close button for the popup */
    .close-button {
        cursor: pointer;
        position: absolute;
        top: 10px;
        right: 10px;
    }
    </style>
    <script>
        const USER_ROLES = {
            PARENT: 'Parent',
            TEACHER: 'Teacher',
            HEAD_TEACHER: 'Head Teacher',
            SCHOOL_DIRECTOR: 'School Director',
        };

        const currentUserRole = '<?php echo $userRole; ?>';

        function updateChatInterface(userRole) {
            switch (userRole) {
                case USER_ROLES.PARENT:
                    // Parent-specific chat interface logic
                    console.log('Parent-specific logic');
                    break;

                case USER_ROLES.TEACHER:
                    // Teacher-specific chat interface logic
                    console.log('Teacher-specific logic');
                    break;

                case USER_ROLES.HEAD_TEACHER:
                    // Head Teacher-specific chat interface logic
                    console.log('Head Teacher-specific logic');
                    break;

                case USER_ROLES.SCHOOL_DIRECTOR:
                    // School Director-specific chat interface logic
                    console.log('School Director-specific logic');
                    break;

                default:
                    // Default logic
                    console.log('Default logic');
                    break;
            }
        }

        updateChatInterface(currentUserRole);
    </script>
</head>

<body>
    <div class="chat-container">
        <div class="recipient-container">
            <h3>Recipients</h3>
            <ul class="recipient-list">
                <?php
                if ($result && $result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<li class="recipient-item" data-user-id="' . $row['id'] . '" data-role="' . $row['role'] . '">' . $row['username'] . ' - ' . $row['role'] . '</li>';
                    }
                } else {
                    echo '<p>No recipients available.</p>';
                }
                ?>
            </ul>
        </div>

        <div class="chat-window">
            <div class="chat-header">
                <h3 id="chat-title">Chat Title</h3>
                <span id="close-button">X</span>
            </div>
            <div id="chat-messages" class="chat-messages"></div>
            <form class="message-form" id="message-form">
                <input type="text" name="message" id="message-input" placeholder="Type your message..." required>
                <button type="button" id="send-button">Send</button>
            </form>
        </div>
    </div>

    <script>

function refreshChat(recipientId) {
            fetchAndDisplayMessages(recipientId);
        }

        function setupChatRefresh(recipientId) {
            // Refresh the chat every 5 seconds (adjust the interval as needed)
            setInterval(() => {
                refreshChat(recipientId);
            }, 5000);
        }

        const recipientList = document.querySelector('.recipient-list');
        const chatMessages = document.getElementById('chat-messages');
        const messageForm = document.getElementById('message-form');
        const messageInput = document.getElementById('message-input');
        const chatTitle = document.getElementById('chat-title');
        const closeButton = document.getElementById('close-button');

        closeButton.addEventListener('click', () => {
            chatMessages.innerHTML = '';
            chatTitle.textContent = 'Chat Title';
        });

        // recipientList.addEventListener('click', (event) => {
        //     const selectedRecipient = event.target;
        //     if (selectedRecipient && selectedRecipient.classList.contains('recipient-item')) {
        //         const recipientId = selectedRecipient.getAttribute('data-user-id');
        //         const recipientRole = selectedRecipient.getAttribute('data-role');
        //         openChat(recipientId, recipientRole);
        //     }
        // });

        recipientList.addEventListener('click', (event) => {
            const selectedRecipient = event.target;
            if (selectedRecipient && selectedRecipient.classList.contains('recipient-item')) {
                const recipientId = selectedRecipient.getAttribute('data-user-id');
                const recipientRole = selectedRecipient.getAttribute('data-role');
                openChat(recipientId, recipientRole);
                setupChatRefresh(recipientId); // Set up automatic refresh for the selected recipient
            }
        });
        function openChat(recipientId, recipientRole) {
        console.log(`Opening chat with user ID ${recipientId} - Role: ${recipientRole}`);

        const activeRecipient = document.querySelector('.recipient-item.active');
        if (activeRecipient) {
            activeRecipient.classList.remove('active');
        }

        const selectedRecipient = document.querySelector(`.recipient-item[data-user-id="${recipientId}"]`);
        if (selectedRecipient) {
            selectedRecipient.classList.add('active');
        }

        // Fetch the user's name, role, and ID based on recipientId
        fetch(`get_user_info.php?user_id=${recipientId}`)
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    const userName = result.user_name;
                    const userRole = result.user_role;
                    const userId = result.user_id;

                    // Update the chat header with name, role, and ID
                    updateChatHeader(userName, userRole, userId);
                } else {
                    console.error('Error fetching user info:', result.error);
                }
            })
            .catch(error => console.error('Error fetching user info:', error));

        fetchAndDisplayMessages(recipientId);
    }

    function updateChatHeader(name, role, id) {
        const chatTitle = document.getElementById('chat-title');
        chatTitle.textContent = `Chat with ${role} - ${id} (${name})`;
    }

        function fetchAndDisplayMessages(recipientId) {
            fetch(`get_messages.php?recipient_id=${recipientId}`)
                .then(response => response.json())
                .then(result => {
                    if (result.success) {
                        const messages = result.messages;
                        console.log('Received messages:', messages);

                        chatMessages.innerHTML = '';

                        messages.forEach(message => {
                            const sender = message.sender_id == <?php echo $userId; ?> ? 'sent' : 'received';
                            addMessageToChat(sender, message.message_text, message.timestamp);
                        });
                    } else {
                        console.error('Error fetching messages:', result.error);
                    }
                })
                .catch(error => console.error('Error fetching messages:', error));
        }

        function sendMessage(recipientId, messageText) {
            fetch('send_message.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `recipient_id=${recipientId}&message_text=${encodeURIComponent(messageText)}`,
                })
                .then(response => response.json())
                .then(result => {
                    if (result.success) {
                        console.log('Message sent successfully');
                    } else {
                        console.error('Error sending message:', result.error);
                    }
                })
                .catch(error => console.error('Error sending message:', error));
        }

        function addMessageToChat(sender, messageText, timestamp) {
            const messageElement = document.createElement('div');
            messageElement.classList.add('message');

            const contentElement = document.createElement('div');
            contentElement.classList.add('message-content', sender === 'sent' ? 'sender-message-content' : 'received-message-content');
            contentElement.textContent = messageText;

            const timestampElement = document.createElement('div');
            timestampElement.classList.add('timestamp');
            timestampElement.textContent = timestamp;

            messageElement.appendChild(contentElement);
            messageElement.appendChild(timestampElement);
            chatMessages.appendChild(messageElement);

            chatMessages.scrollTop = chatMessages.scrollHeight;
        }

        const sendButton = document.getElementById('send-button');
        sendButton.addEventListener('click', () => {
            const selectedRecipient = document.querySelector('.recipient-item.active');
            const messageText = messageInput.value.trim();

            if (selectedRecipient && messageText !== '') {
                const recipientId = selectedRecipient.getAttribute('data-user-id');
                sendMessage(recipientId, messageText);
                messageInput.value = '';
            }
        });
    </script>
    <script>
    // ... (your existing script)

    function refreshChat(recipientId) {
        fetchAndDisplayMessages(recipientId);
    }

    function setupChatRefresh(recipientId) {
        // Refresh the chat every 5 seconds (adjust the interval as needed)
        setInterval(() => {
            refreshChat(recipientId);
        }, 5000);
    }

    const sendButton = document.getElementById('send-button');
    sendButton.addEventListener('click', () => {
        const selectedRecipient = document.querySelector('.recipient-item.active');
        const messageText = messageInput.value.trim();

        if (selectedRecipient && messageText !== '') {
            const recipientId = selectedRecipient.getAttribute('data-user-id');
            sendMessage(recipientId, messageText);
            messageInput.value = '';

            // After sending the message, refresh the chat
            refreshChat(recipientId);
        }
    });

    recipientList.addEventListener('click', (event) => {
        const selectedRecipient = event.target;
        if (selectedRecipient && selectedRecipient.classList.contains('recipient-item')) {
            const recipientId = selectedRecipient.getAttribute('data-user-id');
            const recipientRole = selectedRecipient.getAttribute('data-role');
            openChat(recipientId, recipientRole);
            setupChatRefresh(recipientId); // Set up automatic refresh for the selected recipient
        }
    });

    // ... (your existing script)
</script>


    <?php include 'partials/footer.php'; ?>
</body>

</html>
