<?php
session_start();
include 'includes/db.php';
include 'includes/functions.php';
include 'partials/header.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Check if the logged-in user has the role of school director
if ($_SESSION['role'] !== 'school_director') {
    header("Location: login.php");
    exit();
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['reply_inquiry'])) {
        $inquiry_id = $_POST['inquiry_id'];
        $response = $_POST['response'];

        // Update the inquiry with the response
        reply_to_inquiry($inquiry_id, $response);
    }
}

// Get the list of inquiries
$inquiries = get_all_inquiries();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reply to Inquiries - KGHS</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        .dashboard-container {
            max-width: 800px;
            margin: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        form {
            margin-bottom: 10px;
        }

        h3 {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <div class="header">
            <h2>Reply to Inquiries</h2>
        </div>

        <div class="content">
            <!-- Display inquiries and provide forms for replying -->
            <table>
                <tr>
                    <th>Inquiry ID</th>
                    <th>User ID</th>
                    <th>User Name</th>
                    <th>Email</th>
                    <th>Inquiry</th>
                    <th>Response</th>
                    <th>Action</th>
                </tr>
                <?php foreach ($inquiries as $inquiry): ?>
                    <tr>
                        <td><?php echo $inquiry['inquiry_id']; ?></td>
                        <td><?php echo $inquiry['user_id']; ?></td>
                        <td><?php echo $inquiry['user_name']; ?></td>
                        <td><?php echo $inquiry['user_email']; ?></td>
                        <td><?php echo $inquiry['inquiry_text']; ?></td>
                        <td><?php echo $inquiry['response'] ?? 'Not replied yet'; ?></td>
                        <td>
                            <!-- Reply form -->
                            <form method="post" style="display: inline-block;">
                                <input type="hidden" name="inquiry_id" value="<?php echo $inquiry['inquiry_id']; ?>">
                                <label for="response">Response:</label>
                                <textarea name="response" rows="3" cols="30" required></textarea>
                                <button type="submit" name="reply_inquiry">Reply</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>

    <?php include 'partials/footer.php'; ?>
</body>
</html>
