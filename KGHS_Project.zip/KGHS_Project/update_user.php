<?php
session_start();
include 'includes/db.php';  // Include the database connection file
include 'includes/functions.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Check if the logged-in user has the role of school director
if ($_SESSION['role'] !== 'school_director') {
    header("Location: login.php");
    exit();
}

// Process form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_user'])) {
        // Update a user's information
        $id = $_POST['user_id'];
        $username = $_POST['username'];
        $email = $_POST['email'];
        $role = $_POST['role'];
        $child_names = ($_POST['role'] === 'parent') ? $_POST['child_names'] : null;
        $active = ($_POST['active'] == 1) ? 1 : 0;  // Assuming you have an input named 'active' in your form

        update_user($id, $username, $email, $role, $child_names, $active);
    }
}
?>
