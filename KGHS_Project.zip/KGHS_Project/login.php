<?php
session_start(); // Ensure session is started at the beginning of your script
include 'includes/db.php';
include 'includes/functions.php';
include 'partials/header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Fetch user details from the database
    $user = get_user_by_username($username);

    if ($user && password_verify($password, $user['password'])) {
        // Login successful
         // Set the session variables
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['role'] = $user['role'];


        // Redirect based on role
        if ($user['role'] === 'parent') {
            header("Location: parent_dashboard.php");
            exit();
        } elseif ($user['role'] === 'teacher') {
            header("Location: teacher_dashboard.php");
            exit();
        } elseif ($user['role'] === 'head_teacher') {
            header("Location: head_teacher_dashboard.php");
            exit();
        } elseif ($user['role'] === 'school_director') {
            header("Location: school_director_dashboard.php");
            exit();
        } elseif ($user['role'] === 'head_of_finance') {
            header("Location: head_of_finance_dashboard.php");
            exit();
        } else {
            // Handle other roles or redirect accordingly
            echo "Login successful for other roles!";
            exit();
        }
    } else {
        // Login failed
        echo "Invalid username or password!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - KGHS</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="login-container">
        <h2>Login to KGHS</h2>

        <form action="" method="post" class="login-form">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <button type="submit">Login</button>
        </form>

        <p>Don't have an account? <a href="register.php">Register here</a>.</p>
    </div>

    <?php include 'partials/footer.php'; ?>
</body>
</html>
